package com.example.sodkiller

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }

        val title = TextView(this).apply {
            text = "SOD Killer Modern"
            textSize = 22f
        }

        val desc = TextView(this).apply {
            text = "يمنع إعادة تشغيل الهاتف عند إطفاء الشاشة بسبب مشكلة الكيرنل المخصص.\nاضغط تشغيل ثم اسمح باستثناء تحسين البطارية."
            textSize = 14f
            setPadding(0, 24, 0, 48)
        }

        val startButton = Button(this).apply {
            text = "تشغيل الحماية"
            setOnClickListener {
                val intent = Intent(this@MainActivity, WakeLockService::class.java)
                ContextCompat.startForegroundService(this@MainActivity, intent)
            }
        }

        val stopButton = Button(this).apply {
            text = "إيقاف الحماية"
            setOnClickListener {
                val intent = Intent(this@MainActivity, WakeLockService::class.java).apply {
                    action = WakeLockService.ACTION_STOP
                }
                startService(intent)
            }
        }

        val batteryButton = Button(this).apply {
            text = "استثناء من تحسين البطارية"
            setOnClickListener { requestIgnoreBatteryOptimizations() }
        }

        layout.addView(title)
        layout.addView(desc)
        layout.addView(startButton)
        layout.addView(stopButton)
        layout.addView(batteryButton)

        setContentView(layout)
    }

    private fun requestIgnoreBatteryOptimizations() {
        val packageName = packageName
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            !pm.isIgnoringBatteryOptimizations(packageName)
        ) {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        }
    }
}
